//
//  YMUpLoadFTP.h
//  YMCrashUpLoadFTP
//
//  Created by YuMing on 16/10/26.
//  Copyright © 2016年 YM. All rights reserved.
//

#import <Foundation/Foundation.h>

/** 
 ****** 特别注意需要引入依赖库 ********
 SystemConfiguration.framework,
 AssetsLibrary.framework,
 AudioToolbox.framework,
 CoreTelephony.framework,
 AVFoundation.framework
 并且工程中需要有一个.mm文件
 比如"AppDelegate.mm" 后缀改成.mm即可
 包内部已经包含网络请求判断类Reachability文件项目中如果有该类请删除
 */

@interface YMUpLoadFTP : NSObject
/**
 *  @author 俞明, 16-10-26 11:10:32
 *
 *  崩溃日志上传方法
 *
 *  @param server    FTP服务器地址不用带("ftp://")
 *  @param user      登录账号
 *  @param password  登录密码
 *  @param directory 文件存放目录
 *  自动创建目录层级，默认在第一个层级目录下创建Ini配置文件，如果存在则不创建。
 *  自动根据Ini文件的配置来设置是否将本地的错误日志上传到服务器
 */
+ (void)UpLoadWithServer:(NSString *)server user:(NSString *)user password:(NSString *)password directory:(NSString *)directory;

@end
