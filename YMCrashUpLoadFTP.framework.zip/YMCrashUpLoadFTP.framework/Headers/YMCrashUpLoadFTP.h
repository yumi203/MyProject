//
//  YMCrashUpLoadFTP.h
//  YMCrashUpLoadFTP
//
//  Created by YuMing on 16/10/26.
//  Copyright © 2016年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for YMCrashUpLoadFTP.
FOUNDATION_EXPORT double YMCrashUpLoadFTPVersionNumber;

//! Project version string for YMCrashUpLoadFTP.
FOUNDATION_EXPORT const unsigned char YMCrashUpLoadFTPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YMCrashUpLoadFTP/PublicHeader.h>

//正常使用只调用该类就行
#import <YMCrashUpLoadFTP/YMUpLoadFTP.h>
//崩溃日志写到本地类
#import <YMCrashUpLoadFTP/CrashClass.h>
//网络请求判断类
#import <YMCrashUpLoadFTP/Reachability.h>
//ftp上传类
#import <YMCrashUpLoadFTP/FTPManager.h>

