//
//  FTPManager.h
//  UpLoadFTP
//
//  Created by apple on 16/7/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, FTPStep) {
    FTPStepCheckDir              = 0,
    FTPStepCreateDir                ,
    FTPStepCheckHasIni              ,
    FTPStepUpLoadIni                ,
    FTPStepDownIniAndReadIni        ,
    FTPStepUpLoadLog
};

@interface FTPManager : NSObject

- (instancetype)initWithServer:(NSString *)server user:(NSString *)user password:(NSString *)password directory:(NSString *)directory;

@end

